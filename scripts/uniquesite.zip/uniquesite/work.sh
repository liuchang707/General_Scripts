cd Argali
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
cd GazellaPrzewalskyi
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
cd MountainNyala
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
cd TibetanAntelope
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
cd WhiteLippedDeer
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
cd Yak
#perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/compare.pl /public/home/linzeshan/project/domestication/07.second_compare/new_cat/pep_compare/work_flow/cat_out_V3.txt && \
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/01_filter_all_diff_pos_by_conserv.pl  diff.pos >filter_conserve.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/Argali/02_filter_all_diff_pos_by_pfam_and_conserv.pl diff.pos >filter_conserve_domain.diff.pos
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl diff.pos variant.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve.diff.pos variant_filter_conserve.out
perl /home/liuchang/project/HypoxicAdaptation/01.gene/100percent/convert_pname_gname.pl filter_conserve_domain.diff.pos variant_filter_conserve_domain.out
cd ..
