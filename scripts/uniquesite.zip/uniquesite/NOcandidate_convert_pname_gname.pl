use strict;
use warnings;
my $file1 = "/public/home/linzeshan/project/DF_assemble/15.special_analysis/analysis_by_hand/bos_gene_cds_pep.list";
#my $file1 = $ARGV[0];
open IN,$file1 or die $!;
my $hash = {};
my $shha = {};
my $gene_name_bos = {};
while(<IN>){
	next if $_ =~ /^Gene/;
	next if $_ =~ /^\s+$/;
	my @array = split(/\s+/,$_);
	$array[0] =~ /gene:(ENSBTAG\d+)/;
	my $gene = $1;
	$array[1] =~ /transcript:(ENSBTAT\d+)/;
	my $trans = $1;
	my $name = "NA";
	if ($array[3] =~ /gene_symbol:(.*)/){
		$name = $1;	
	}	
	$hash->{$trans} = $gene;
	$shha->{$gene}  = $trans;
	$gene_name_bos->{$gene} = $name;
}
my $condidate_gene = {};
#my $file3 = "Reindeer_4_geneV2.csv";
#my $file3 = $ARGV[1];
my $file3 = "gene_list";
my $gene_list1 = "IN_list";
my $gene_list2 = "OUT_list";
my %key_pos_hash;my %other_pos_hash;
open LIST1,$gene_list1 or die $!;
open LIST2,$gene_list2 or die $!;
my $only_species;my $op = 0;my $ed = 0;

while(<LIST1>){
	chomp;$key_pos_hash{$_} = 1;
	$op++;
	$only_species = $_;
}
while(<LIST2>){
	chomp;$other_pos_hash{$_} = 2;
	$ed++;
}
open IN3,$file3 or die $!;
while(<IN3>){
	chomp;
#	next if $_ =~ /MSTN/;
#	next if $_ =~ /PXPHOS/;
#	next if $_ =~ /^Gene_name/;
	my @array = split(/\s+/,$_);
	next unless $_ =~ /ENSBTAG/;
	$array[1] =~ s/\.(\d+)//g;
	$condidate_gene->{$array[0]} = $array[1];
}
my $file2 = $ARGV[0];#"/public/home/linzeshan/project/DF_assemble/15.special_analysis/analysis_by_hand/round-2/all_diff.pos";#$ARGV[0];
#my $file2 = $ARGV[2];
my $key_hash = {};
my $other_hash = {};
open IN2,$file2 or die $!;
my $result = {};
while(<IN2>){
	chomp;
	my @array = split(/\s+/,$_);
	unless ($_ =~ /^ENSBTAT/){
		my $new_ed = 0;
		my $len = @array;
		for(my $i = 0;$i<$len;$i++){
			if (exists ($key_pos_hash{$array[$i]})){
				$key_hash->{$i+1} = 1;
			}
			elsif(exists ($other_pos_hash{$array[$i]})){
				$other_hash->{$i+1} = 2;
			}
			elsif($ed == 0){
				$other_hash->{$i+1} = 2;
				$new_ed ++;
			}
		}
		$ed = $new_ed if $ed == 0;
		next;
	}
	my $tran_pos = $array[0];
	my $tran;my $pos;
	if($tran_pos =~ /(\w+)-(\d+)/){
		$tran = $1;$pos = $2;
	}
	else{
		print $tran_pos;
		next;
	}
	my $gene = $hash->{$tran};
	#	if (exists ($condidate_gene->{$gene})){
		my $len = @array;
		my $time_hash = {};
		my $in_time_hash = {};
		for(my $i = 1;$i<$len;$i++){
			if (exists ($other_hash->{$i})){
				if (exists ($time_hash->{$array[$i]})){
					$time_hash->{$array[$i]} += 1;
				}
				else{
					$time_hash->{$array[$i]} = 1;
				}
			}
			if (exists ($key_hash->{$i})){
				if (exists ($in_time_hash->{$array[$i]})){
					$in_time_hash->{$array[$i]} += 1;
				}
				else{
					$in_time_hash->{$array[$i]} = 1;
				}
			}
		}
		my $word = "\t\t$pos:\t";
		foreach my $key(sort {$time_hash->{$b}<=>$time_hash->{$a}} keys %{$time_hash}){
			my $value = $time_hash->{$key};
			$word.= "$key($value),";
		}
		$word =~ s/,$//g;
		my $in_word = "";
		foreach my $key(sort {$in_time_hash->{$b}<=>$in_time_hash->{$a}} keys %{$in_time_hash}){
			my $value = $in_time_hash->{$key};
			$in_word .= "$key($value),";
		}
		$in_word =~ s/,$//g;
		$word .= "\t=>\t$in_word";
		if ($op == 1){
			$word .= ":$only_species\n";
		}
		else{
			$word .= "\n";
		}
		if (exists ($result->{$gene})){
			$result->{$gene} .= $word;
		}
		else{
			$result->{$gene} = $word;
		}
		#	}
		#print $gap."\t".$array[0]."\t".$array[1]."\t".$condidate_gene->{$gap}."\n";
}
my $file4 = $ARGV[1];#out file
open YAHA,">$file4" or die $!;
foreach my $key(keys %{$result}){
	if (exists ($result->{$key})){
		my $value = $result->{$key};
		my $trans = $shha->{$key};
		my $gene_name = "NO_Name";
		if (exists ($gene_name_bos->{$key})){
			$gene_name = $gene_name_bos->{$key};	
		}
		if (exists ($condidate_gene->{$key})){
			$gene_name = $condidate_gene->{$key}}
		print YAHA $gene_name."\t".$key."\t".$trans.":\n".$value;
	}
}



