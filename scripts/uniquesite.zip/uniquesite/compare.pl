use strict;
use warnings;
my $file = $ARGV[0];
open IN,$file or die $!;
#open OUT,">same.txt" or die $!;
#open OUT2,">diff.txt" or die $!;
open OUT,">diff.pos" or die $!;
open OUT2,">score.out" or die $!;
my $high_score = 10000;
my $score_hash = {};
my %key_pos_hash;my %other_pos_hash;
my $gene_list1 = "IN_list";
my $gene_list2 = "OUT_list";
open LIST1,$gene_list1 or die $!;
my $op = 0;
my $ed = 0;
while(<LIST1>){
	chomp;
	$key_pos_hash{$_} = 1;
	$op++;
}
open LIST2,$gene_list2 or die $!;
while(<LIST2>){
	chomp;
	$other_pos_hash{$_} = 2;
	$ed++;
}
die "Please Input Species In List1 !" if $op == 0;
#my %pos_hash = ("AfricanBuffalo"=>1,"Cattle"=>2,"Daviddeer"=>1,"goat"=>2,"Sheep"=>2,"Yak"=>2,"TibetanAntelope"=>1,"WhiteLippedDeer"=>1,"MuntiacusCrinifrons"=>1,"RoeDeer"=>1,"Pronghorn"=>1,"Hartebeest"=>1,"GreaterKudu"=>1);
my $key_hash = {};
my $other_hash = {};
my $new_ed = 0;
while(<IN>){
	my $word = $_;
	chomp($word);
	my @array = split(/\s+/,$word);
	if ($_ =~ /^Af/){
		my $len = @array;
		my @tt;my @kk;
		for(my $i = 0;$i<$len;$i++){
			if (exists ($key_pos_hash{$array[$i]})){
				$key_hash->{$i+1} = 1;
				push (@tt,$array[$i]);
				
			}
			elsif(exists ($other_pos_hash{$array[$i]})){
				$other_hash->{$i+1} = 2;
				push (@kk,$array[$i]);
			}
			elsif ($ed == 0){
				$other_hash->{$i+1} = 2;
				push (@kk,$array[$i]);
				$new_ed ++;
			}
		}
		my @head_word = (@tt,@kk);
		my $head = join("\t",@head_word);
		print OUT $head."\n";
		$ed = $new_ed if $ed == 0;
		next;
	}
	my $len = @array;
	$_ =~ /(ENS\w+)\-(\d+)/;my $id = $1;my $pos = $2;
	my $score = 0;
	my $same_pach = 0;
	my $diff_pach = 0;
	my $amovo = {};
	my $laji = 0;my $jila = 0;
	foreach my $key (keys %{$key_hash}){
		if ($array[$key] eq "X" || $array[$key] eq "+"){$laji ++;}
		if (exists ($amovo->{$array[$key]})){
			$amovo->{$array[$key]} += 1;
		}
		else{
			$amovo->{$array[$key]} = 1;
		}
	}
	foreach my $key(keys %{$other_hash}){
		if ($array[$key] eq "X" || $array[$key] eq "+"){$jila ++;}
	}
	next if $laji/$op > 0.5;
	next if $jila/$ed > 0.5;
	my $x_key;
	foreach my $key (sort {$amovo->{$b}<=>$amovo->{$a}}keys %{$amovo}){
		$x_key = $key;
		last;
	}
	my @in_word;my @out_word;
	for(my $i=0;$i<$len;$i++){
		if (exists ($key_hash->{$i})){
			$same_pach ++ if $array[$i] eq $x_key;
			push(@in_word,$array[$i]);
	#		$same_pech -- if $array[$i] ne $x_key;
		}
		if (exists ($other_hash->{$i})){
	#		$diff_pech -- if $array[$i] eq $x_key;
			$diff_pach ++ if $array[$i] ne $x_key;
			push(@out_word,$array[$i]);
		}
	}
	$same_pach /= $op;
	$diff_pach /= $ed;
	next if $diff_pach < 1;
	next if $same_pach < 1;
	my $pach = ($same_pach + $diff_pach)/2;
	my $kage =1/$high_score;$kage+=1-$pach;$kage = 1/$kage;
	$kage = $high_score*$high_score if $pach == 1;
	if ($pach > 0.5){
		if (exists ($score_hash->{$id})){
			$score_hash->{$id} += $kage;
		}
		else{
			$score_hash->{$id} = $kage;
		}
		my @out_word = (@in_word,@out_word);
		my $out_tt = join("\t",@out_word);
		print OUT $id."-".$pos."\t".$out_tt."\n";
	}
}
foreach my $key (sort {$score_hash->{$b}<=>$score_hash->{$a}} keys %{$score_hash}){
	print OUT2 $key."\t".$score_hash->{$key}."\n";
}



=p
	#my $Akey = $array[13];my $Ckey = $array[12];
	#my $print_key = 1;
	#$print_key = 0 if $array[13] == $array[1] && $array[1] == $array[52] && $array[52] == $array[17] && $array[52] == $array[28];
	#$print_key = 0 if $array[46] == $array[]
	foreach my $array(@array){
		next if $array =~ /EN/;
		next if $array eq "X";
		$print_key = 0 unless $Akey eq $array;
#		$array = "($array)" unless $Akey eq $array;
		
	}
#=cut
	my @other_deer = ($array[12],$array[14],$array[15],$array[34],$array[35],$array[36],$array[41],$array[50],$array[51]);
	my $time_hash = {};
	foreach my $kk (@other_deer){
		if (exists $time_hash->{$kk}){$time_hash->{$kk} += 1;}
		else{ $time_hash->{$kk} = 1;}
	}
	my $N;my $N_t = 0;
	foreach my $yami(keys %{$time_hash}){
		if ($time_hash->{$yami} > $N_t){
	#		print $time_hash->{$yami}.":";
	#		print $N_t."@";
			$N = $yami;$N_t = $time_hash->{$yami};
		}
	}
	my $pach = 100;
	$pach = 1000000 if $N_t == 7;
	$pach = 100000000 if $N_t == 8;
	$pach = 10000000000 if $N_t == 9;
	my $count_score = 0;
	foreach my $kk (@other_deer){
		$count_score ++ if $x_key ne $kk;
	}
	$score += $pach if $count_score >= 7;
	print OUT $_ if $count_score >= 7;
	if (exists ($score_hash->{$id})){
		$score_hash->{$id} += $score;
	}
	else{
		$score_hash->{$id} = $score;
	}
#	my $out = join("\t",@array);
#	print OUT $out."\n" if $print_key == 1;
#	print OUT2 $out."\n" if $print_key == 0;
}
foreach my $key (sort{$score_hash->{$a}<=>$score_hash->{$b}} keys %{$score_hash}){
	print OUT2 $key."\t".$score_hash->{$key}."\n";
}
