#use strict;
#use warnings;
my $file3 = "/public/home/linzeshan/project/DF_assemble/15.special_analysis/analysis_by_hand/round-4/bos_gene_cds_pep.list";
open IN3,$file3 or die $!;
my $hash = {};
while(<IN3>){
        next if $_ =~ /^Gene/;
        next if $_ =~ /^\s+$/;
        my @array = split(/\s+/,$_);
        $array[0] =~ /gene:(ENSBTAG\d+)/;
        my $gene = $1;
        $array[1] =~ /transcript:(ENSBTAT\d+)/;
        my $trans = $1;
        $hash->{$gene} = $trans;
}
my $file1 = "/public/home/linzeshan/project/DF_assemble/15.special_analysis/analysis_by_hand/round-4/bos.fasta.pfam";
open IN,$file1 or die $!;
my $pfam = {};
my $count = 1;
while(<IN>){
	chomp;
	next if $_ =~ /^#/	;
	my @array = split(/\s+/,$_);
	$array[0] =~ /bos\|(\w+)\.\d+/;
	my $id = $1;
	if (exists($hash->{$id})){
		my $trans = $hash->{$id};
		$pfam->{$trans}->{$count}->{start} = $array[3];
		$pfam->{$trans}->{$count}->{end} = $array[4];
	}
	$count++;
}
my $file2 = $ARGV[0];#"all_diff.pos";
open IN2,$file2 or die $!;
while(<IN2>){
	chomp;
	if ($_ =~ /^Argali/){
		print $_."\n";
		next;
	}
	my @array = split(/\t/,$_);
	$array[0] =~ /(\w+)\-(\d+)/;
	my $id = $1;my $pos = $2;
	my $len = @array;my $key1;

	for(my $i = 1;$i<$len;$i++){
		if ($i == 1 || $array[$i] eq "X" || $array[$i] eq "+" || $array[$i] =~ /^\s+$/){
			next;
		}
		$key1 = $array[$i];
	}
	my $oishi = 0;
	for(my $i = 1;$i<$len;$i++){
		if ($i == 1 || $array[$i] eq "X" || $array[$i] eq "+" || $array[$i] =~ /^\s+$/){
			next;
		}
		$oishi = 1 if $key1 ne $array[$i];
	}
	next if $oishi == 1;

	if (exists ($pfam->{$id})){
		foreach my $key(keys %{$pfam->{$id}}){
			my $start = $pfam->{$id}->{$key}->{start};
			my $end = $pfam->{$id}->{$key}->{end};
			if ($start<=$pos && $end >= $pos){
				print $_."\n";
			}
		}
	}
}



