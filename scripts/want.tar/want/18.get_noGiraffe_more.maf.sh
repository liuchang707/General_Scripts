/public/home/liuchang/scripts/ucsc_tools/mafsInRegion noGiraffe_more noGiraffe_more.withGiraffe.maf /public/home/liuchang/projects/giraffe/01.HCE/splitmaf/25/goat.sing.maf
