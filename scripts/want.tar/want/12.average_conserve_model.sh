ls /public/home/liuchang/projects/giraffe/02.HCE_nogiraffe/split_maf/*split/*/*.ss.cons.mod > cons.txt
./bin/phyloBoot --read-mods '*cons.txt' --output-average ave.cons.mod
