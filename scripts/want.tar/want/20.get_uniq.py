#!/usr/env/python

import re
import sys
import os

inf1=open(sys.argv[1])
inf2=open('species')
out=open(sys.argv[1]+'.diff','w')
out2=open(sys.argv[1]+'.Giraffeloss','w')

dic={}
sp={}
for line in inf2:
	line=line.strip().split()
	sp[line[0]]=1

pos=''
for line in inf1:
	if re.search('^s',line):
		line=line.strip().split()
		if line[1].split('.')[0]=="goat":
			pos=line[2]+'_'+str(int(line[2])+int(line[3])-1)		
		dic[line[1].split('.')[0]]=line[6].upper()
	elif re.search('^$',line):
		if 'Giraffe' not in dic and 'Giraffe3' not in dic and len(dic)>=7:
			out2.write(pos+'\n')
		if 'Giraffe' in dic and 'Giraffe3' in dic and len(dic)>=8: ## two giraffe are included and totally at least 8 
			length=len(dic['goat'])
			count={}
			for key in sp:
				if not re.search('Giraffe',key):
					if key not in dic:
						count[key]='NA'
					else:
						count[key]=0
			count['Giraffe']=0
			for i in range(length):
				site={}
				#diff={}
				for key in sp:
					#print(key)
					if key in dic:
						if dic[key][i] not in site:
							site[dic[key][i]]=[]
							site[dic[key][i]].append(key)
						else:
							site[dic[key][i]].append(key)
				if len(site)==2 and dic['Giraffe'][i]==dic['Giraffe3'][i]:
					for s in site:
						if len(site[s])==1:
							if site[s][0] not in count:
								count[site[s][0]]=1
							else:
								count[site[s][0]]+=1
						if len(site[s])==2 and 'Giraffe' in site[s]:
							if 'Giraffe' not in count:
								count['Giraffe']=1
							else:
								count['Giraffe']+=1
			out.write(pos+'\t'+str(length))
			for c in sorted(count.keys()):
				if count[c]=='NA':
					out.write('\t'+c+': NA')
				else:
					out.write('\t'+c+': '+str(count[c]))	
			out.write('\n')
		dic={}
