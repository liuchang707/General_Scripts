#!/usr/env/python
import re
import sys
import os
#inf=open(sys.argv[1])

#os.system('rm 23.all.zscore')
out=open('23.all.zscore','a')
out.write('chr\tpos_start\tpos_end\tlength\tCattle\tDaviddeer\tForestMuskDeer10x\tGiraffe\tOkapi\tPronghorn\tReindeer\tSpermWhale\tTragulusNew\tgoat\n')
	
#for f in os.popen('ls /public/home/liuchang/projects/giraffe/01.HCE/ELEMENTS/goat.*.sing.maf.newbed.maf.diff.align.zscore.sort'):
for f in os.popen('ls ELEMENTS/goat.*.Giraffe.sing.maf.bed.more.bed.maf.diff.align.zscore'):
	inf=open(f.strip())
	chrname=f.split('/')[-1].split('.')[1]
	for line in inf:
		if not re.search('pos',line):
			line=line.strip().split()
			out.write(chrname+'\t'+line[0].split('_')[0]+'\t'+line[0].split('_')[1]+'\t')
			aa="\t".join(line[1:])
			out.write(aa+'\n')
	inf.close()
out.close()
