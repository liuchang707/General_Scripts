#!/usr/env/python

import re
import sys
import os

inf1=open(sys.argv[1])
inf2=open(sys.argv[2])
out=open(sys.argv[2]+'.more.bed','w')
site1={}
chrname=sys.argv[1].split('/')[-1].split('.')[1]
for line in inf1:
	line=line.strip().split()
	for i in range(int(line[1]),int(line[2])+1):
		site1[i]=1

for line in inf2:
	count=0
	length=0
	line=line.strip().split()
	length=int(line[2])-int(line[1])+1
	for i in range(int(line[1]),int(line[2])+1):
		if i in site1:
			count+=1
	if float(count)/float(length)<0.5:
		out.write(chrname+'\t'+line[1]+'\t'+line[2]+'\n')
		

	

