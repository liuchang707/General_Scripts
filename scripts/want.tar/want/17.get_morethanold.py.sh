python 17.get_morethanold.py /public/home/liuchang/projects/giraffe/01.HCE/ELEMENTS/goat.sing.maf.new.bed ELEMENTS/goat.sing.nogiraffe.maf.new.bed
