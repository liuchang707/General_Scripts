#!/usr/env/python

import re
import sys
import os
inf=open(sys.argv[1])
out=open(sys.argv[1]+'.giraffesort','w')
score={}
for line in inf:
	if re.search('pos',line):
		out.write(line)
	else:
		if not re.search('NO',line):
			l=line
			line=line.strip().split()
			score[l]=float(line[5])
for k in sorted(score.items(),key=lambda item:item[1],reverse=True):
	out.write(k[0])
inf.close()
out.close()


