#!/usr/env/python

import re
import sys
import os

inf1=open(sys.argv[1])# extracted maf
inf2=open(sys.argv[2])# the bed used to extract maf
out=open(sys.argv[2]+'giraffeless','w')
site1={}
chrname=sys.argv[1].split('/')[-1].split('.')[1]
for line in inf1:
	if not re.search('^#',line) and re.search('goat',line):
		line=line.strip().split()
		for i in range(int(line[3])):
			site1[int(line[2])+i]=1

for line in inf2:
	count=0
	length=0
	line=line.strip().split()
	length=int(line[2])-int(line[1])+1
	for i in range(int(line[1]),int(line[2])+1):
		if i in site1:
			count+=1
	if float(count)/float(length)<0.8:
		out.write(chrname+'\t'+line[1]+'\t'+line[2]+'\n')
		

	

